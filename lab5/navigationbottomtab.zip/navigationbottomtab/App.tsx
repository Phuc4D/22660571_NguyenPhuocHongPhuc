import { NavigationContainer } from '@react-navigation/native';
import React from 'react';
import BottomTab from './BottomTab';

export default function App(){
    return (
        <NavigationContainer>
            <BottomTab/>
        </NavigationContainer>
    )
}