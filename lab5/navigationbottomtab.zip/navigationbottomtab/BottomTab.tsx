import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react';

import Home from './Home';
import Profile from './Profile';
import Search from './Search';

const Tab = createBottomTabNavigator();

export default function BottomTab(){
    return(
        <Tab.Navigator
            screenOptions={({route}) => ({
                headerShown: false,
                tabBarIcon:({color, size})=> {
                      let iconName;

                    if(route.name === 'Home') iconName = 'home';
                    else if(route.name === 'Profile') iconName = 'person';
                    else if(route.name === 'Search') iconName = 'search';
                    return <Ionicons name={iconName as any} size={size} color = {color}/>;
                },
            })}
        >
            <Tab.Screen name="Home" component={Home}></Tab.Screen>
            <Tab.Screen name="Profile" component={Profile}></Tab.Screen>
            <Tab.Screen name="Search" component={Search}></Tab.Screen>

        </Tab.Navigator>
   );
}